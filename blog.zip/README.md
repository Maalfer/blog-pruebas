Comandos a ejecutar para desplegar la web:

```bash
pip install -r requirements.txt
python3 app.py
```

En caso de estar en linux primero crear un entorno virtual:

```bash
python3 -m venv librerias
source librerias/bin/activate
python3 app.py
```
